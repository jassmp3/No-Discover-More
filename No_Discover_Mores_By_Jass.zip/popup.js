const toggle = document.getElementById("toggle");
const status = document.getElementById("status");

function render(enabled) {
  toggle.setAttribute("aria-checked", String(enabled));
  status.innerHTML = `Status: <strong>${enabled ? "On" : "Off"}</strong>`;
}

chrome.storage.local.get({ hideDiscoverMore: true }, ({ hideDiscoverMore }) => {
  render(hideDiscoverMore);
});

toggle.addEventListener("click", async () => {
  const enabled = toggle.getAttribute("aria-checked") !== "true";
  await chrome.storage.local.set({ hideDiscoverMore: enabled });
  render(enabled);
});
