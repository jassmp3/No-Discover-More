(() => {
  const STORAGE_KEY = "hideDiscoverMore";
  const STYLE_ID = "ndm-hide-discover-more-style";
  let enabled = true;
  let observer;
  const hiddenNodes = new Set();

  function textOf(el) {
    return (el.innerText || el.textContent || "").replace(/\\s+/g, " ").trim().toLowerCase();
  }

  function isDiscoverMoreControl(el) {
    if (!(el instanceof Element)) return false;
    const tag = el.tagName.toLowerCase();
    const role = (el.getAttribute("role") || "").toLowerCase();
    const label = [
      el.getAttribute("aria-label"),
      el.getAttribute("title"),
      el.getAttribute("data-testid"),
      el.getAttribute("data-bdd")
    ].filter(Boolean).join(" ").toLowerCase();
    const txt = textOf(el);

    const looksInteractive = ["button", "a"].includes(tag) || role === "button" ||
      el.hasAttribute("tabindex") || /discover more/.test(label);

    return looksInteractive &&
      (/^discover more$/.test(txt) || /discover more/.test(label));
  }

  function addStyle() {
    if (document.getElementById(STYLE_ID)) return;
    const style = document.createElement("style");
    style.id = STYLE_ID;
    style.textContent = `
      [data-ndm-hidden="true"] { display: none !important; visibility: hidden !important; }
    `;
    (document.head || document.documentElement).appendChild(style);
  }

  function scan() {
    if (!enabled) {
      document.querySelectorAll('[data-ndm-hidden="true"]').forEach(el => {
        el.removeAttribute("data-ndm-hidden");
      });
      hiddenNodes.clear();
      return;
    }

    addStyle();

    // Check likely controls first, then descendants in case Ticketmaster wraps the label.
    const candidates = document.querySelectorAll(
      'button, a, [role="button"], [aria-label], [title], [data-testid], [data-bdd]'
    );

    candidates.forEach(el => {
      if (!isDiscoverMoreControl(el)) return;

      // Prefer the control itself; avoid hiding the entire panel or a large parent.
      let target = el;
      if (el.tagName.toLowerCase() !== "button" && el.tagName.toLowerCase() !== "a" &&
          el.getAttribute("role") !== "button") {
        const parentControl = el.closest('button, a, [role="button"]');
        if (parentControl) target = parentControl;
      }

      target.setAttribute("data-ndm-hidden", "true");
      hiddenNodes.add(target);
    });
  }

  function start() {
    chrome.storage.local.get({ [STORAGE_KEY]: true }, result => {
      enabled = result[STORAGE_KEY] !== false;
      scan();
    });

    if (observer) observer.disconnect();
    observer = new MutationObserver(() => scan());
    observer.observe(document.documentElement, { childList: true, subtree: true, characterData: true });
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local" || !changes[STORAGE_KEY]) return;
    enabled = changes[STORAGE_KEY].newValue !== false;
    scan();
  });

  if (document.documentElement) start();
  else document.addEventListener("DOMContentLoaded", start, { once: true });
})();
